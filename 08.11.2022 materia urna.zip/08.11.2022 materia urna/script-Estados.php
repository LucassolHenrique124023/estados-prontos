<?php
//abre o arquivo 
$arquivo = fopen("estados.csv","r");

$contador = 0;

//laco de repeticao que converte as linhas do csv em array
while ($linha = fgetcsv($arquivo, 1000, ",") ){
    //validacao importacao
if ($contador >= 1){
    $sql = "INSERT INTO Estados (EstadosID,Nome,Sigla)
    VALUES (".$linha[0].",'".$linha[1]."','".trim($linha[2])."');<br>";
echo $sql;

}
//add +1 im contador
$contador++;
}
//fecha a execucao do arquivo
fclose($arquivo);

/*INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (35,'São Paulo',' SP');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (41,'Paraná',' PR');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (42,'Santa Catarina',' SC');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (43,'Rio Grande do Sul',' RS');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (50,'Mato Grosso do Sul',' MS');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (11,'Rondônia',' RO');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (12,'Acre',' AC');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (13,'Amazonas',' AM');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (14,'Roraima',' RR');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (15,'Pará',' PA');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (16,'Amapá',' AP');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (17,'Tocantins',' TO');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (21,'Maranhão',' MA');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (24,'Rio Grande do Norte',' RN');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (25,'Paraíba',' PB');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (26,'Pernambuco',' PE');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (27,'Alagoas',' AL');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (28,'Sergipe',' SE');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (29,'Bahia',' BA');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (31,'Minas Gerais',' MG');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (33,'Rio de Janeiro',' RJ');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (51,'Mato Grosso',' MT');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (52,'Goiás',' GO');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (53,'Distrito Federal',' DF');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (22,'Piauí',' PI');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (23,'Ceará',' CE');
INSERT INTO Estados (EstadosID,Nome,Sigla) VALUES (32,'Espírito Santo',' ES');*/
?>