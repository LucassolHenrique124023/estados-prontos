<?php
//abre o arquivo 
$arquivos = fopen("Partidos.csv","r");

$contador = 0;
//laco de repeticao que converte as linhas do csv em array
while ($linha = fgetcsv($arquivos, 1000, ",") ){
    //validacao importacao
if ($contador >= 1){
    $sql = "INSERT INTO partidos (PartidosID, Nome, Sigla, Numlegenda, Excluido)
    VALUES (".$linha[0].", '".$linha[1]."', '".$linha[2]."',".$linha[3].",'F');<br>";
echo $sql;

}
//add +1 im contador
$contador++;
}
//fecha a execucao do arquivo
fclose($arquivo);
?>